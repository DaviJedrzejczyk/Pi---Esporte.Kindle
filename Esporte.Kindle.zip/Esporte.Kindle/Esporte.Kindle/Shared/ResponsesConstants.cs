﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared
{
    internal class ResponsesConstants
    {
        public const string MENSAGEM_SUCESSO = "Operação realizada com sucesso!";
        public const string MENSAGEM_FALHA = "Operação falhou!";
    }
}
