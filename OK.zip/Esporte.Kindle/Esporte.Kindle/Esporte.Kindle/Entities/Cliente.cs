﻿namespace Entities
{
    public class Cliente : Pessoa
    {
        public Cliente(int id, string nome, string cpf, DateTime dataNascimento, string telefone, string email, string rG, Genero genero, string telefone2, int pontosAcumulados) : base(id, nome, cpf, dataNascimento, telefone, email, rG, genero)
        {
            Telefone2 = telefone2;
            PontosAcumulados = pontosAcumulados;
        }
        public Cliente()
        {

        }

        public string Telefone2 { get; set; }
        public bool IsAtivo { get; set; }

    }

}