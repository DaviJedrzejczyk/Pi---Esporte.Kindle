﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities.Enums;

namespace Entities
{
    public class Funcionario
    {
        public Funcionario()
        {

        }
        public Funcionario(int id, string nome, string cpf, DateTime dataNascimento, string telefone, string email, string rG, Endereco endereco, Genero genero, string senha, NiveldeAcesso nivelAcesso) : base(id, nome, cpf, dataNascimento, telefone, email, rG, genero)
        {
            Senha = senha;
            Nivel_Acesso = nivelAcesso;
            Endereco = endereco;
        }
        public string Senha { get; set; }
        public NivelDeAcesso Nivel_Acesso { get; set; }
        public Endereco Endereco { get; set; }
        public int EnderecoId { get; set; }
        public bool IsAtivo { get; set; }
    }

}
}
